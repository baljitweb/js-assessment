import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { NewsComponent } from './home/news/news.component';
import { LocationsComponent } from './home/locations/locations.component';

import {DashboardModule} from './dashboard/dashboard.module';

import { appRoutingModule } from './app.routing';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    NewsComponent,
    LocationsComponent
  ],
  imports: [
    BrowserModule,
    DashboardModule,
    appRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
