import { Component } from '@angular/core';

@Component({
    templateUrl: './barChart.component.html'
})
export class barChartComp { }