
import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
    selector: 'dash-charts',
    templateUrl: './charts.component.html'
})
export class ChartsComponent {
    constructor(private router: Router) { }
    showbarchart() {
         this.router.navigateByUrl('dashboard/charts/bar-chart'); // with link
        // this.router.navigateByUrl( ['/charts', {outlets: {'db2': ['bar-chart']}}]  ); // with button click event
    }
}