
import {Component} from '@angular/core';

@Component({
    selector:'dash-graphs',
    templateUrl:'./graphs.component.html'
})
export class GraphsComponent{}