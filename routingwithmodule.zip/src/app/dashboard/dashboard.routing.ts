import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

// components
import { HomeComponent} from '../home/home.component';
import { DashboardComponent } from './dashboard.component';
import { ChartsComponent } from './charts/charts.component';
import { GraphsComponent } from './graphs/graphs.component';
import { barChartComp } from './charts/barChart/barChart.component';

// routing constant
const dashboardRoute: Routes = [
    { path: '', component: HomeComponent },
    {
        path: 'dashboard', component: DashboardComponent,
        children: [
            { path: 'charts', component: ChartsComponent, 
                children:[
                    {path:'bar-chart', component:barChartComp},
                    // { path: '**', redirectTo: '/dashboard', pathMatch:"full" },
                ]
            },
            { path: 'graphs', component: GraphsComponent }
        ]
    },
    { path: '**', redirectTo: '/dashboard', pathMatch:"full" },

];

@NgModule({
    imports: [
        RouterModule.forChild(dashboardRoute)
    ],
    exports: [RouterModule]
})
export class DashboardRouting { }