import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

// components
import { DashboardComponent } from './dashboard.component';
import { ChartsComponent } from './charts/charts.component';
import { barChartComp } from './charts/barChart/barChart.component';
import { GraphsComponent } from './graphs/graphs.component';
import { DashboardRouting } from './dashboard.routing';

@NgModule({
    declarations: [
        DashboardComponent,
        ChartsComponent,
        barChartComp,
        GraphsComponent
    ],
    imports: [
        CommonModule,
        RouterModule
    ],
    exports: [
        DashboardRouting
    ]
})
export class DashboardModule { }