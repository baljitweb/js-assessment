import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

// route components
import { HomeComponent } from './home/home.component';
import { NewsComponent } from './home/news/news.component';
import { LocationsComponent } from './home/locations/locations.component';


//routes
const routes: Routes = [
    
    
    { path: 'home', component: HomeComponent,
        children:[
            {path:'news', component:NewsComponent},
            {path:'locations', component:LocationsComponent}
        ]
    },
    {path:'', redirectTo: '/home', pathMatch: 'full' },
    {path:'**', redirectTo: '/home', pathMatch: 'full' },
   
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class appRoutingModule { }