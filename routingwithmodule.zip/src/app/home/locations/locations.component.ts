
import {Component} from '@angular/core';

@Component({
    selector:'home-locations',
    templateUrl:'locations.component.html'
})
export class LocationsComponent{}