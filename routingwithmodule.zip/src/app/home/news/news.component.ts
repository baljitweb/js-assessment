
import {Component} from '@angular/core';

@Component({
    selector:'home-news',
    templateUrl:'./news.component.html'
})
export class NewsComponent{}